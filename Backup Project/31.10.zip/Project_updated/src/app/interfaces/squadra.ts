export interface Squadra {
  id: number,
  players : any []
}
