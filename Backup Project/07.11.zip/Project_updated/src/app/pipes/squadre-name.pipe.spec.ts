import { SquadreNamePipe } from './squadre-name.pipe';

describe('SquadreNamePipe', () => {
  it('create an instance', () => {
    const pipe = new SquadreNamePipe();
    expect(pipe).toBeTruthy();
  });
});
