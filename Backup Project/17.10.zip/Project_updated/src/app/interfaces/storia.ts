export interface Storia {
  id : number,
  nome : string,
  urlBackground: string
}
